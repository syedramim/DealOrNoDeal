# DealOrNoDeal

- Complete.zip is the completed project utilizing tkinter and GUI
- DealorNoDeal.py is our original code without tkinter and GUI
- Calulation.py is used to find the offer based on what round you are in.
- Dealorno.xlsx is our cited excel sheet we used in calculation.py
- Differentcases.py is used to show how it doesn't effect your odds of winning the max amount based on what case you choose at the start
- Montehall.py is used to show how you have a 50% chance of winning more money by either not switching or switching.
