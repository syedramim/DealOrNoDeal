from tkinter import *
from PIL import ImageTk, Image
import random
import numpy as np

window = Tk()
Input = Entry(window, width="20")
Input.place(x=1100, y=800)
images = ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg", "7.jpg", "8.jpg",
          "9.jpg", "10.jpg", "11.jpg", "12.jpg", "13.jpg", "14.jpg", "15.jpg", "16.jpg",
          "17.jpg", "18.jpg", "19.jpg", "20.jpg", "21.jpg", "22.jpg", "23.jpg",
          "24.jpg", "25.jpg", "26.jpg"]
Entries = set()


def print_labels():
    xloc = 0
    yloc = 120
    yc = 0
    for image in images:
        file = Image.open(image)
        res_dd = file.resize((75, 75))
        file = ImageTk.PhotoImage(res_dd)
        label1 = Label(image=file)
        label1.image = file
        label1.place(x=xloc, y=yloc)
        xloc += 120
        yc += 1
        if yc > 1 and yc % 6 == 0:
            xloc = 0
            yloc += 120


caseValues = [0.01, 1, 5, 10, 25, 50, 75, 100, 200, 300, 400, 500, 750, 1000, 5000, 10000, 25000, 50000, 75000, 100000,
              200000, 300000, 400000, 500000, 750000, 1000000]
np.random.shuffle(caseValues)

firstcase = 0
amount = 0
globentry = 0
firstind = 0


def removeCase(entry, ind):
    global firstcase
    if ind == 0:
        firstcase = caseValues[entry - 1]
    global amount
    amount = caseValues[entry - 1]
    caseValues[entry - 1] = None
    return caseValues


def getEX(l):
    sum = 0
    numCases = 0
    for i in range(len(l)):
        if l[i] != None:
            sum += l[i]
            numCases += 1
    expectedValue = round((sum / numCases), 2)
    return expectedValue


def printMaxMoney(l):
    max = 0
    casesLeft = 0
    for i in range(len(l)):
        if l[i] != None and l[i] > max:
            max = l[i]
        if l[i] != None:
            casesLeft += 1
    prob = (1 / casesLeft) * 100
    prob = round(prob, 2)
    return max


def getnewEX(r, e):
    if r == 1:
        return round(e * (.106804), 2)
    elif r == 2:
        return round(e * (.215985), 2)
    elif r == 3:
        return round(e * (.373357), 2)
    elif r == 4:
        return round(e * (.518857), 2)
    elif r == 5:
        return round(e * (.630936), 2)
    elif r == 6:
        return round(e * (.737169), 2)
    elif r == 7:
        return round(e * (.871227), 2)
    elif r == 8:
        return round(e * (.91328), 2)
    return e


def moreThanOffer(offer, l):
    moreThanOffer = 0
    for i in range(len(l)):
        if l[i] != None and l[i] > offer:
            moreThanOffer += 1
    return moreThanOffer


def numinList(l):
    numInList = 0
    for i in range(len(l)):
        if l[i] != None:
            numInList += 1
    return numInList


def getLastCase(l):
    count = 0
    for i in range(len(l)):
        if l[i] != None:
            return l[i]


def checkCase(entry, l):
    if l[entry - 1] != None:
        return 1
    else:
        return 0


casesGone = 0
roundd = 1
verbose = 6
picked = 0


def update():
    global roundd, verbose, picked, casesGone
    entry = Input.get()

    xval = 700
    yval = 200
    lwidth = 45
    lheight = 15

    if entry.lower() == "deal":
        dealtext = f"YOU'VE TAKEN THE DEAL. GAME OVER\n"
        deallabel = Label(window, text=dealtext, bg="black", fg="white", font=("Times", "16", "bold italic"), width=lwidth, height=lheight)
        deallabel.place(x=xval, y=yval)
    elif entry.lower() == "no deal":
        nodealtext = f"LETS KEEP GOING\n"
        nodeallabel = Label(window, text=nodealtext, bg="black", fg="white", font=("Times", "16", "bold italic"), width=lwidth, height=lheight)
        nodeallabel.place(x=xval, y=yval)
    elif entry == "Yes":
        yestext = f"You decided to switch\n" + f"You just made ${getLastCase(caseValues)}!!\n"
        yeslabel = Label(window, text=yestext, bg="black", fg="white", font=("Times", "16", "bold italic"), width=lwidth, height=lheight)
        yeslabel.place(x=xval, y=yval)
    elif entry == "No":
        notext = f"You decided NOT to switch\n" + f"You just made ${firstcase}!!\n"
        nolabel = Label(window, text=notext, bg="black", fg="white", font=("Times", "16", "bold italic"), width=lwidth, height=lheight)
        nolabel.place(x=xval, y=yval)
    else:
        entry = int(entry)
        if checkCase(entry, caseValues) == 1:
            casesGone += 1
        global firstind
        removeCase(entry, firstind)
        expected = getEX(caseValues)
        mamount = printMaxMoney(caseValues)
        if firstind == 0:
            removed = f"Your case is now number {entry}\n" + f" We hold onto this until the end.\n"
            firstcaselabel = Label(window, text=removed, bg="black", fg="white", font=("Times", "16", "bold italic"), width=lwidth, height=lheight)
            firstcaselabel.place(x=xval, y=yval)
            firstind += 1
        elif picked == verbose - 1:
            roundd += 1
            if verbose > 1:
                verbose -= 1
            picked = 0
            newEX = getnewEX(roundd, expected)
            more = moreThanOffer(newEX, caseValues)
            inList = numinList(caseValues)
            prob = (more / inList) * 100
            prob = round(prob, 2)
            if casesGone == 24:
                stext = f"Two Cases Left\n" + f"We now know that the last two values are $ {getLastCase(caseValues)}, and ${firstcase},\n" + f"The question is... Which one is in your case?\n" + f"If you want you can switch. If you switch you open the last case on the stage\n" + "If you don't switch, you win whatever is in the case you picked in the beginning.\n" + f"So, do you want to switch?\n"
                slabel = Label(window, text=stext, bg="black", fg="white", font=("Times", "12", "bold italic"), width=65, height=lheight)
                slabel.place(x=xval, y=yval)
            else:
                removed = f"Your offer is ${newEX}\n" + f"There are {more} more cases left worth more than offer\n" + f"There are {inList} cases left\n" + f"You have a {prob} % chance of making more than this offer\n" + f"Deal or No Deal?\n"
                label2 = Label(window, text=removed, bg="black", fg="white", font=("Times", "16", "bold italic"), width=lwidth, height=lheight)
                label2.place(x=xval, y=yval)
        elif firstind == 1:
            picked += 1
            removed = f"The entry of {entry} has been removed\n" + f"You just removed the case with % {amount} in it\n" + f"The Most Money You Can Make Is:  {mamount}\n" + f"You Have a  {round((1 / numinList(caseValues)) * 100, 2)}% chance of Winning the Max Amount\n"
            label3 = Label(window, text=removed, bg="black", fg="white", font=("Times", "16", "bold italic"), width=lwidth, height=lheight)
            label3.place(x=xval, y=yval)

    if int(entry) > len(images):
        return 1

    file = Image.open(f"remove.jpg")
    res_dd = file.resize((75, 75))
    file = ImageTk.PhotoImage(res_dd)
    label1 = Label(image=file)
    label1.image = file

    xloc = 0
    yloc = 120
    xinc = 120
    yinc = 120

    for i in range(1, 6):
        if entry % 6 == i:
            xloc += (i - 1) * xinc
            break
        if entry % 6 == 0:
            xloc += 5 * xinc
            break

    for i in range(1, 6):
        if entry > (i * 6):
            continue
        else:
            addit = (i - 1) * yinc
            yloc += addit
            break

    label1.place(x=xloc, y=yloc)


def main():
    window.title("Deal or No Deal")
    window.geometry("1280x1024")
    window.configure(bg="black")
    window.iconbitmap(r"deal.ico")

    dealndeal = Image.open("deal.jpg")
    res_dd = dealndeal.resize((1280, 100))
    dealndeal = ImageTk.PhotoImage(res_dd)
    label1 = Label(image=dealndeal)
    label1.image = dealndeal
    label1.pack()

    print_labels()

    myb = Button(window, text="Update", command=update)
    myb.place(x=1225, y=800)
    window.mainloop()


main()