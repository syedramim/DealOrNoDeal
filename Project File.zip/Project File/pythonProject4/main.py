from tkinter import *
from PIL import ImageTk, Image

window = Tk()
Input = Entry(window, width="20")
Input.place(x=1100, y=800)
images = ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg", "7.jpg", "8.jpg",
          "9.jpg", "10.jpg", "11.jpg", "12.jpg", "13.jpg", "14.jpg", "15.jpg", "16.jpg",
          "17.jpg", "18.jpg", "19.jpg", "20.jpg", "21.jpg", "22.jpg", "23.jpg",
          "24.jpg", "25.jpg", "26.jpg"]
Entries = set()


def print_labels():
    xloc = 0
    yloc = 120
    yc = 0
    for image in images:
        file = Image.open(image)
        res_dd = file.resize((75, 75))
        file = ImageTk.PhotoImage(res_dd)
        label1 = Label(image=file)
        label1.image = file
        label1.place(x=xloc, y=yloc)
        xloc += 120
        yc += 1
        if yc > 1 and yc % 6 == 0:
            xloc = 0
            yloc += 120


def update():
    amount = 0
    mamount = 0
    percent = 0

    entry = Input.get()

    if entry == "Deal" or entry == "No Deal":
        print("Do Something")
        return 0
    else:
        entry = int(entry)

    if entry > len(images):
        return 1

    Entries.add(entry)
    if len(Entries) == 24:
        print("Now we present the Monty Hall problem for choice of switching or not")

    file = Image.open(f"remove.jpg")
    res_dd = file.resize((75, 75))
    file = ImageTk.PhotoImage(res_dd)
    label1 = Label(image=file)
    label1.image = file

    xloc = 0
    yloc = 120
    xinc = 120
    yinc = 120

    for i in range(1, 6):
        if entry % 6 == i:
            xloc += (i - 1) * xinc
            break
        if entry % 6 == 0:
            xloc += 5 * xinc
            break

    for i in range(1, 6):
        if entry > (i * 6):
            continue
        else:
            addit = (i - 1) * yinc
            yloc += addit
            break

    label1.place(x=xloc, y=yloc)

    removed = f"The entry of {entry} has been removed\n" + f"You just removed the case with % {amount} in it\n" + f"The Most Money You Can Make Is:  {mamount}\n" + f"You Have a  {percent}% chance of Winning the Max Amount\n"
    label2 = Label(window, text=removed, bg="black", fg="white", font=("Times", "16", "bold italic"))

    label2.place(x=750, y=325)


def main():
    window.title("Deal or No Deal")
    window.geometry("1280x1024")
    window.configure(bg="black")
    window.iconbitmap(r"deal.ico")

    dealndeal = Image.open("deal.jpg")
    res_dd = dealndeal.resize((1280, 100))
    dealndeal = ImageTk.PhotoImage(res_dd)
    label1 = Label(image=dealndeal)
    label1.image = dealndeal
    label1.pack()

    print_labels()

    myb = Button(window, text="Update", command=update)
    myb.place(x=1225, y=800)
    window.mainloop()


main()
